# limiter

Caching decorator based on cache-tools. 


# Installation

## Requirements

 - Python 3.7+
 
## Installing from PyPI

```bash
pip3 install cache
```

# Usage

```python3
...
```